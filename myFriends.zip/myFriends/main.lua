--- STEAMODDED HEADER
--- MOD_NAME: My Friends
--- MOD_ID: myFriends
--- MOD_AUTHOR: [Andrew Keniuk]
--- MOD_DESCRIPTION: oh brother these jokers are not balanced
--- PREFIX: myfre
----------------------------------------------
------------MOD CODE -------------------------


local lovely = require("lovely")


SMODS.Atlas{
    key = 'Jokers', --atlas key
    path = 'jokers.png', --atlas' path
    px = 71, --width of one card
    py = 95 -- height of one card
}


-- Ahren's Joker
SMODS.Joker{
    key = 'ahren',
    loc_txt = {
        name = 'Inconspicuous Egg', 
        text = {
            'Triples Blind requirement,',
            'earn {C:money}$20{} after every hand,',
            '{C:red}self-destructs after the round'
        }
    },
    rarity = 3,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = false,
    atlas = 'Jokers',
    pos = {x = 0, y = 0},
    cost = 8,

    config = { extra = {money = 20}, },

   
    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.money} }
    end,

    calculate = function(self, card, context)
        
        if context.joker_main then
            return {
                card = card,
                dollars = card.ability.extra.money,
            }
        end

        if context.setting_blind then
            G.GAME.blind.chips = G.GAME.blind.chips * 3
            G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
            G.HUD_blind:recalculate()
        
            
        elseif context.end_of_round and context.cardarea == G.jokers and not context.blueprint then

            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('tarot1')
                    card.T.r = -0.2
                    card:juice_up(0.3, 0.4)
                    card.states.drag.is = true
                    card.children.center.pinch.x = true
					G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.5, blockable = false,
						func = function()
							G.jokers:remove_card(card)
							card:remove()
							card = nil
							return true;
						end
					})) 
					return true
				end
			})) 
			return {
				message = "BYE AHREN"
            }
        end
    end
}

-- Zirka's Joker
SMODS.Joker{
    key = 'zirka',
    loc_txt = {
        name = '{C:chips}BLUE{}', 
        text = {
            '{C:chips}+555{} chips, {X:mult,C:white}X0.6{} mult',
            'creates a random {C:planet}Planet{} card'
        }
    },
    rarity = 3,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    atlas = 'Jokers',
    pos = {x = 1, y = 0},
    cost = 7,

    config = { extra = {chips = 555, xmult = 0.6}, },

   
    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.chips, center.ability.extra.xmult, G.localization.misc.poker_hands['High Card']} }
    end,

    calculate = function(self, card, context)
        
        if context.joker_main then
            return {
                card = card,
                chips = card.ability.extra.chips,
				Xmult = card.ability.extra.xmult
                
            }
        end
            
        if context.after and context.cardarea == G.jokers and not context.blueprint then

            G.E_MANAGER:add_event(Event({
				trigger = 'after',
				delay = 0.4,
				func = function()
					if G.consumeables.config.card_limit > #G.consumeables.cards then
                        play_sound('timpani')
						local new_card = create_card('Planet', G.consumeables, nil, nil, nil, nil, nil, 'zirka')
						new_card:add_to_deck()
						G.consumeables:emplace(new_card)
						card:juice_up(0.3, 0.5)
					end
					return true
				end
			}))
        end
    end
}

-- Ore's Joker
SMODS.Joker{
    key = 'ore',
    loc_txt = {
        name = 'Reckoning', 
        text = {
            '{C:red}0{} discards',
            '{X:mult,C:white}X8{} mult on the last hand'
        }
    },
    rarity = 3,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    atlas = 'Jokers',
    pos = {x = 2, y = 0},
    cost = 9,

    config = { extra = {xmult = 8}, },

   
    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.xmult} }
    end,

    calculate = function(self, card, context)
        
        if context.joker_main and G.GAME.current_round.hands_left == 0 then
            return {
                Xmult = card.ability.extra.xmult
            }
        end
            
        if context.setting_blind and not card.getting_sliced then
            ease_discard(-G.GAME.current_round.discards_left, nil, true)
        end
    end
}

SMODS.Joker{
    key = 'roman',
    loc_txt = {
        name = 'We Do Some Trolling', 
        text = {
            '{C:red}+42{} mult, {X:mult,C:white}X10{} mult',
            '{C:red}1 in 9 chance every blind{}',
            '{C:red}selected that the game ends{}'
        }
    },
    rarity = 3,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    atlas = 'Jokers',
    pos = {x = 3, y = 0},
    cost = 5,

    config = { extra = {mult = 42, xmult = 10, odds = 9, hand_loss = 10}, },

   
    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.mult, center.ability.extra.xmult, center.ability.extra.odds, center.ability.extra.hand_loss} }
    end,

    calculate = function(self, card, context)
        
        if context.joker_main then
            return {
                card = card,
                mult = card.ability.extra.mult,
				Xmult = card.ability.extra.xmult
            }
        end      

        if context.setting_blind and context.cardarea == G.jokers and not context.blueprint and pseudorandom("roman") < G.GAME.probabilities.normal/card.ability.extra.odds then
            G.hand:change_size(-card.ability.extra.hand_loss)
            return {
               message = "get trolled"
            }
        end
           
        -- old effect (number of hands goes to 0)
        -- if context.before and context.cardarea == G.jokers and not context.blueprint and pseudorandom("roman") < G.GAME.probabilities.normal/card.ability.extra.odds and not card.ability.has_scored then
        --     G.GAME.current_round.hands_left = 0
        --     return {
        --         message = "get trolled"
        --     }
        -- end

    end
}

SMODS.Joker{
    key = 'andrew',
    loc_txt = {
        name = 'Benevolent Creator', 
        text = {
            'During first played hand, creates copies equal to the',
            'size of the played hand minus 1, destroys the rest',
            'If played hand is only one card, every card will be debuffed'
        }
    },
    rarity = 3,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = false,
    atlas = 'Jokers',
    pos = {x = 4, y = 0},
    cost = 10,

    config = {},

   
    loc_vars = function(self,info_queue,center)
        return {G.localization.misc.poker_hands['High Card'].lower(G.localization.misc.poker_hands['High Card'])}
    end,

    calculate = function(self, card, context)   

        if context.destroy_card and context.cardarea == G.play and context.destroy_card ~= context.full_hand[1] and not context.blueprint and G.GAME.current_round.hands_played == 0 then
            G.E_MANAGER:add_event(Event({
                trigger = "before",
                delay = 0.4,
                func = function()
                    card:juice_up(0.3, 0.4)
                    G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                    local _c = copy_card(context.full_hand[1], nil, nil, G.playing_card)
                    _c:start_materialize()
                    _c:add_to_deck()
                    G.deck.config.card_limit = G.deck.config.card_limit + 1
                    table.insert(G.playing_cards, _c)
                    G.hand:emplace(_c)
                    playing_card_joker_effects({ _c })
                    return true
                end,
            }))
            return {remove = true}
        end

        if context.before and context.cardarea == G.jokers and not context.blueprint and #context.full_hand == 1 then
            for i, v in pairs(G.deck.cards) do
                v:set_debuff(true)
            end
            for i, v in pairs(G.hand.cards) do
                v:set_debuff(true)
            end
            return {
                message = "devastating."
            }
        end
    end
}